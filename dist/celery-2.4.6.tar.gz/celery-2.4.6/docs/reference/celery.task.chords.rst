======================================================
 celery.task.chords
======================================================

.. contents::
    :local:
.. currentmodule:: celery.task.chords

.. automodule:: celery.task.chords
    :members:
    :undoc-members:
