.. currentmodule:: celery.contrib.rdb

.. automodule:: celery.contrib.rdb

    .. autofunction:: set_trace
    .. autofunction:: debugger
    .. autoclass:: Rdb
