==========================================
 celery.events.dumper
==========================================

.. contents::
    :local:
.. currentmodule:: celery.events.dumper

.. automodule:: celery.events.dumper
    :members:
    :undoc-members:
