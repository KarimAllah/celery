============================================
 celery.backends.mongodb
============================================

.. contents::
    :local:
.. currentmodule:: celery.backends.mongodb

.. automodule:: celery.backends.mongodb
    :members:
    :undoc-members:
